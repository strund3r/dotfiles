# [Brew](https://brew.sh/)

## Install

```bash
chmod +x installBrew.sh && ./installBrew.sh
```

## Using

```bash
brew bundle install
```